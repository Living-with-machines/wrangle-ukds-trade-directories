from . import __app_name__
from .pathlib import Path
from .file_wrangling import (
    consolidate_files,
    consolidate_guides,
    _sort_pdf,
    _sort_txt,
    get_files,
)
from .log import log
from .patterns import NUMBER

import click
import pandas as pd


@click.command(name=__app_name__)
@click.option(
    "--input",
    type=click.Path(exists=True),
    prompt="Input UKDS data (directory)",
    help="The input path where the UKDS trade directories can be found.",
)
@click.option(
    "--output",
    type=click.Path(exists=False),
    prompt="Output UKDS data (directory)",
    help="The output path where the consolidated UKDS trade directories should be located.",
)
@click.option(
    "--metadata",
    type=click.Path(exists=False),
    prompt="Metadata (CSV file)",
    help="The path to the CSV file with corresponding metadata.",
)
def main(input, output, metadata):
    """Simple app that wrangles the UKDS Trade Directories data folder."""

    # Ensure input, output are the correct type
    input, output = Path(input), Path(output)

    # 1. Consolidate files

    # 1a. PDF guides

    pdf_guides = get_files(
        input,
        fullname="guide.pdf",
        key=lambda x: NUMBER.search(str(x.parent.parent.parent)).groups()[0],
    )
    consolidate_guides(pdf_guides, input, output, kind="pdf")

    # 1b. HTML guides

    html_guides = get_files(
        input,
        fullname="*Information.htm",
        key=lambda x: NUMBER.search(str(x)).groups()[0],
    )
    consolidate_guides(html_guides, input, output, kind="html")

    # 1c. PDF files
    pdf_files = get_files(input, kind="pdf")
    consolidate_files(
        pdf_files.values(), input, output, kind="pdf", sorter_func=_sort_pdf
    )

    # 1d. text files
    txt_files = get_files(input, kind="TXT")
    consolidate_files(
        txt_files.values(), input, output, kind="txt", sorter_func=_sort_txt
    )

    # Add the log
    log(
        {
            "txt_files": txt_files,
            "pdf_files": pdf_files,
            "html_guides": html_guides,
            "pdf_guides": pdf_guides,
        }
    )

    # TODO: continue working on processing metadata (in notebook...)
    df = pd.read_csv(metadata)
    identifiers = set(df.Identifier.to_list())
    print(identifiers)
    exit()


if __name__ == "__main__":
    main()
