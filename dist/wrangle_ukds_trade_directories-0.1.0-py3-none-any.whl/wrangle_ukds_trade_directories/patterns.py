import re

NUMBER = re.compile("(\d{3,4})")
