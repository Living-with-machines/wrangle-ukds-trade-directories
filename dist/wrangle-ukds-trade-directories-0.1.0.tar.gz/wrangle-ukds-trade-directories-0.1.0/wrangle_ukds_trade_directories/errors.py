class NotAFileError(RuntimeError):
    """Raised when the provided path is not a file as expected"""

    pass
