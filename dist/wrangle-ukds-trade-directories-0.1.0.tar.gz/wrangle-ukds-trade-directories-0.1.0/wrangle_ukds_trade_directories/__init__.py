__app_name__ = "wrangle-ukds-trade-directories"
__version__ = "0.1.0"
__description__ = "Simple app that wrangles the UKDS Trade Directories data folder."
